<?php

if(isset($_POST['send'])){

	$output = shell_exec('C:\php-8.1.12\php-cgi.exe kra_score_cron_job.php');
}