<?php

function insert_score_otp_response_log($api_response,$score_msg,$emp_name,$contact_no,$resp_status){
	
	$db = "(DESCRIPTION=(ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.5.6.133)(PORT = 9021)))(CONNECT_DATA=(SERVICE_NAME=CBPROD)))" ;
	$conn = OCILogon("CB_PROD", "admin1", $db);

	$api_response = json_decode($api_response);
	$status = $api_response->status;
	$statusCode = $api_response->statusCode;
	$uniqueId = $api_response->uniqueId;
	$sent_date = date('Y-m-d');
	
	// Insert into log
	$sql = 'BEGIN USP_UPDATE_SMSTRIGGER_LOG(:P_EMP_NUMBER, :P_CONTACT_NUMBER, :P_MESSAGE, :P_UNIQUEID, :P_STATUS_CODE, :P_API_STATUS, :P_SENT_STATUS, :RESULT_OUT); END;';

	$stmt = oci_parse($conn,$sql);

	// Bind the input parameter
	oci_bind_by_name($stmt,':P_EMP_NUMBER',$emp_name,200);
	oci_bind_by_name($stmt,':P_CONTACT_NUMBER',$contact_no,200);
	oci_bind_by_name($stmt,':P_MESSAGE',$score_msg,200);
	oci_bind_by_name($stmt,':P_UNIQUEID',$uniqueId,200);
	oci_bind_by_name($stmt,':P_STATUS_CODE',$statusCode,200);
	oci_bind_by_name($stmt,':P_API_STATUS',$status,200);
	oci_bind_by_name($stmt,':P_SENT_STATUS',$resp_status,200); 
	
	$cursor = oci_new_cursor($conn);
	oci_bind_by_name($stmt,":RESULT_OUT", $cursor,-1,OCI_B_CURSOR);

	oci_execute($stmt);
	oci_execute($cursor);
	oci_free_statement($stmt);
	oci_close($conn);
}	

$file_name = 'role_allocation_cron_log_'.date('d-m-Y_hia').'.txt';
$fp = fopen('logs/'.$file_name ,"a+");

$db = "(DESCRIPTION=(ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.5.6.133)(PORT = 9021)))(CONNECT_DATA=(SERVICE_NAME=CBPROD)))" ;

if($conn = OCILogon("CB_PROD", "admin1", $db))
{
	 fwrite($fp,"Successfully connected to Oracle ");
	//OCILogoff($conn);
}
else
{
	$err = OCIError();
	fwrite($fp,"Connection failed . ");
}
fwrite($fp,"========================================== \n");
//die();
// SMS logic

$sql = 'BEGIN RC_GET_SMS_DATA(:DATA_OUT); END;';

$stmt = oci_parse($conn,$sql);

$cursor = oci_new_cursor($conn);
// Bind the output parameter
oci_bind_by_name($stmt,":DATA_OUT", $cursor,-1,OCI_B_CURSOR);

oci_execute($stmt);

// and now, execute the cursor
oci_execute($cursor);

// Use OCIFetchinto in the same way as you would with SELECT
$offset = $inc = 1;
while ($data = oci_fetch_assoc($cursor)) {

	//echo '<pre>'; print_r($data); die();
	//fwrite($fp,print_r($data, true));

	if($offset == 200){
		fwrite($fp,"Going to sleep at $inc \n");
		sleep(20);
		$offset = 1;
	}
    
	$emp_name = $data['EMP_NAME'];
	$status = $data['STATUS'];
	$fy = 'FY'.$data['FY'];
	$timestamp = date("dmYHms");
	$contact_no = $data['CONTACTNO'];
	if(empty($contact_no)){
		fwrite($fp,"Skipped at $inc \n");
		continue;
	}

	$link = 'https://centralrise.centralbank.co.in/';

	$score_msg = 'Dear '.$emp_name.', Your role '.$status.' for '.$fy.' is pending. Please speak with your manager to complete the same on '.$link.' URL. - CBoI';
	//echo $score_msg; die();
	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => 'https://digimate.airtel.in:35443/BulkPush/PushRequestAPI',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYHOST =>true,
		CURLOPT_SSL_VERIFYPEER =>true,
		CURLOPT_CAINFO =>'C:\airtel_ssl_cert\digimate.airtel.in.crt', 
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_PROXY  =>'10.1.34.100:8080',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS =>'{
			"keyword": "digimate",
			"timestamp": "'.$timestamp.'",
			"dataSet": [
			{
				"message": "'.$score_msg.'",

				"oa": "CENTBK",
				"msisdn": "'.$contact_no.'",
				"channel": "SMS",
				"campaignName": "centralb_u",
				"circleName": "DLT_CBI_AGG",
				"userName": "centalt"
			}
			]
		}',
		CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json'
		),
	));
	$response = curl_exec($curl);
	fwrite($fp,$response);
	curl_close($curl);
	$err = curl_error($curl);
	if($err){
		// Store in db log
		insert_score_otp_response_log($response,$score_msg,$emp_name,$contact_no,'Failed');
	}else{ 
		// Store in db log
		insert_score_otp_response_log($response,$score_msg,$emp_name,$contact_no,'Success');
	}

	fwrite($fp,"Record No : $inc \n");
	$offset++;
	$inc++;
	//die;
}

